def validar_nombre(nombre):
    return nombre.strip() != ""


def validar_edad(edad):
    return edad > 0


def validar_temperatura(temperatura):
    return 35.0 <= temperatura <= 42.0

def mostrar_menu():
    print("\n=== MENÚ PRINCIPAL ===")
    print("1. Agregar paciente")
    print("2. Buscar paciente")
    print("3. Eliminar paciente")
    print("4. Actualizar estado")
    print("5. Mostrar pacientes")
    print("6. Salir")
    print("==================================")

def leer_opcion():
    while True:
        try:
            opcion = int(input("Seleccione una opción: "))
            if 1 <= opcion <= 6:
                return opcion
            else:
                print("Error: debe ingresar una opción entre 1 y 6.")
        except ValueError:
            print("Error: debe ingresar un número entero.")

def agregar_paciente(lista_pacientes):

    nombre = input("Ingrese nombre del paciente: ")

    if not validar_nombre(nombre):
        print("Error: el nombre no puede estar vacío.")
        return

    try:
        edad = int(input("Ingrese edad: "))
    except ValueError:
        print("Error: la edad debe ser un número entero.")
        return

    if not validar_edad(edad):
        print("Error: la edad debe ser mayor que cero.")
        return

    try:
        temperatura = float(input("Ingrese temperatura: "))
    except ValueError:
        print("Error: la temperatura debe ser un número decimal.")
        return

    if not validar_temperatura(temperatura):
        print("Error: la temperatura debe estar entre 35.0 y 42.0.")
        return

    paciente = {
        "nombre": nombre,
        "edad": edad,
        "temperatura": temperatura,
        "atendido": False
    }

    lista_pacientes.append(paciente)
    print("Paciente registrado correctamente.")

def buscar_paciente(lista_pacientes, nombre_buscar):

    for posicion in range(len(lista_pacientes)):
        if lista_pacientes[posicion]["nombre"] == nombre_buscar:
            return posicion

    return -1

def eliminar_paciente(lista_pacientes):

    nombre = input("Ingrese el nombre del paciente a eliminar: ")

    posicion = buscar_paciente(lista_pacientes, nombre)

    if posicion != -1:
        lista_pacientes.pop(posicion)
        print("Paciente eliminado correctamente.")
    else:
        print(f"El paciente '{nombre}' no se encuentra registrado.")

def actualizar_estado(lista_pacientes):

    for paciente in lista_pacientes:

        if paciente["temperatura"] <= 37.0:
            paciente["atendido"] = True
        else:
            paciente["atendido"] = False

    print("Estados actualizados correctamente")


def mostrar_pacientes(lista_pacientes):

    

    print("\n=== LISTA DE PACIENTES ===")

    if len(lista_pacientes) == 0:
        print("No existen pacientes registrados")
        return

    for paciente in lista_pacientes:

        print(f"Nombre: {paciente['nombre']}")
        print(f"Edad: {paciente['edad']}")
        print(f"Temperatura: {paciente['temperatura']}")

        if paciente["atendido"]:
            print("Estado: Atendido")
        else:
            print("Estado: REQUIERE ATENCION")

        print("*" * 45)
pacientes = []

while True:

    mostrar_menu()
    opcion = leer_opcion()

    if opcion == 1:
        agregar_paciente(pacientes)

    elif opcion == 2:

        nombre = input("Ingrese nombre a buscar: ")
        posicion = buscar_paciente(pacientes, nombre)

        if posicion != -1:

            paciente = pacientes[posicion]

            print("\nPaciente encontrado")
            print(f"Posición: {posicion}")
            print(f"Nombre: {paciente['nombre']}")
            print(f"Edad: {paciente['edad']}")
            print(f"Temperatura: {paciente['temperatura']}")
            print(f"Atendido: {paciente['atendido']}")

        else:
            print("Paciente no encontrado")

    elif opcion == 3:
        eliminar_paciente(pacientes)

    elif opcion == 4:
        actualizar_estado(pacientes)

    elif opcion == 5:
        mostrar_pacientes(pacientes)

    elif opcion == 6:
        print("Gracias por usar el sistema. Vuelva Pronto")
        break